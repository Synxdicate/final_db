<?php
require_once 'connect.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>WashFlow</title>
</head>
<body>
    <h1>WashFlow</h1>
    <ul>
        <li><a href="view1_customer_membership.php">1. ข้อมูลลูกค้าและสมาชิก</a></li>
        <li><a href="view2_customer_vehicles.php">2. รถของลูกค้า</a></li>
        <li><a href="view3_employee_info.php">3. ข้อมูลพนักงาน</a></li>
        <li><a href="view4_booking_summary.php">4. สรุปการจอง</a></li>
        <li><a href="view5_service_progress.php">5. สถานะการบริการ</a></li>
        <li><a href="view6_payment_receipt.php">6. การชำระเงินและใบเสร็จ</a></li>
        <li><a href="view7_service_detail.php">7. รายละเอียดบริการ</a></li>
        <li><a href="view8_branch_stats.php">8. สถิติการจองแต่ละสาขา</a></li>
        <li><a href="view9_service_pricing.php">9. ตารางราคาบริการ</a></li>
        <li><a href="view10_active_services.php">10. บริการที่กำลังดำเนินการ</a></li>
        <li><a href="crud.php">insert ข้อมูล</a></li>
    </ul>
</body>
</html>
