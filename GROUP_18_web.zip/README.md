```
git clone https://github.com/Synxdicate/p_db
cd p_db
docker-compose up -d
```

phpmyadmin port 8080<br>
mysql port 3307<br>
apache2 port 80<br>
